#define KLEE_BUILD_MODE "Release"
#define KLEE_BUILD_REVISION "e6ade1cd2a8a253d871dc2fd1e0e7e463160dbe1"
