#include <klee/klee.h>

int main ()
{

int a = 0;
int b = 1;
long long c;
klee_make_symbolic(&c, sizeof(c), "c");

if (c > 1){
 a = 2;
} else {
 b = 5;
}

if (a > 1) {
 b = 9;
} 

a = a + b;

return 1;

}
