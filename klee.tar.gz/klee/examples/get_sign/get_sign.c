/*
 * First KLEE tutorial: testing a small function
 */

#include <klee/klee.h>

/*
int get_sign(int x) {
  if (x == 0)
     return 0;
  
  if (x < 0)
     return -1;
  else 
     return 1;
} 

int main() {
  int a;
  klee_make_symbolic(&a, sizeof(a), "a");
  return get_sign(a);
} 

*/

int test(int p)
{

if (p==0) return 0;
return -1;

}


int main ()
{

int p;

klee_make_symbolic(&p, sizeof(p), "p");
int a= test(p);

p=1;

return 0;
}
