#include <klee/klee.h>

int main ()
{

int a = 0;
int b = 0;
int c, d;
klee_make_symbolic(&c, sizeof(c), "c");
klee_make_symbolic(&d, sizeof(d), "d");

if (c > 1){
 a = 2;
 if (d > 1){
   a =4;
 } else { 
   b = 9;
 }
 a = 7;
} else {
 b = 5;
}

a = a + b;

return 1;

}
