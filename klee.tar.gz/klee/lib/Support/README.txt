This directory holds basic support facilities (data structures,
utilities, etc.) used by klee.
