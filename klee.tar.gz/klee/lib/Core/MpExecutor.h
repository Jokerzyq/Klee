/*
 * MpExecutor.h
 *
 *  Created on: 2016年1月13日
 *      Author: joker
 */

#ifndef LIB_CORE_MPEXECUTOR_H_
#define LIB_CORE_MPEXECUTOR_H_

#include "Executor.h"

#include "klee/ExecutionState.h"
#include "klee/Interpreter.h"
#include "klee/Internal/Module/Cell.h"
#include "klee/Internal/Module/KInstruction.h"
#include "klee/Internal/Module/KModule.h"

using namespace llvm;
using namespace klee;

class MpExecutor : public Executor {

public:

	MpExecutor(const InterpreterOptions &opts, InterpreterHandler *ie);
	virtual ~MpExecutor();

	void executeInstruction(ExecutionState &state, KInstruction *ki);

	void executeMemoryOperation(ExecutionState &state,
		                                        bool isWrite,
		                                        ref<Expr> address,
		                                        ref<Expr> value /* undef if read */,
		                                        KInstruction *target /* undef if write */);


	StatePair fork(ExecutionState &current, ref<Expr> condition, bool isInternal);

	void bindLocal(KInstruction *target, ExecutionState &state,
		                           ref<Expr> value , unsigned id);

};



#endif /* LIB_CORE_MPEXECUTOR_H_ */
