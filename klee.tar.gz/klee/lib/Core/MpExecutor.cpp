/*
 * MpExecutor.cpp
 *
 *  Created on: 2016年1月13日
 *      Author: joker
 */

#include "MpExecutor.h"

#include "Common.h"
#include "Executor.h"
#include "Context.h"
#include "CoreStats.h"
#include "ExternalDispatcher.h"
#include "ImpliedValue.h"
#include "Memory.h"
#include "MemoryManager.h"
#include "PTree.h"
#include "Searcher.h"
#include "SeedInfo.h"
#include "SpecialFunctionHandler.h"
#include "StatsTracker.h"
#include "TimingSolver.h"
#include "UserSearcher.h"
#include "ExecutorTimerInfo.h"

#include "../Solver/SolverStats.h"
#include "klee/ExecutionState.h"
#include "klee/Expr.h"
#include "klee/Interpreter.h"
#include "klee/TimerStatIncrementer.h"
#include "klee/CommandLine.h"
#include "klee/Common.h"
#include "klee/util/Assignment.h"
#include "klee/util/ExprPPrinter.h"
#include "klee/util/ExprSMTLIBPrinter.h"
#include "klee/util/ExprUtil.h"
#include "klee/util/GetElementPtrTypeIterator.h"
#include "klee/Config/Version.h"
#include "klee/Internal/ADT/KTest.h"
#include "klee/Internal/ADT/RNG.h"
#include "klee/Internal/Module/Cell.h"
#include "klee/Internal/Module/InstructionInfoTable.h"
#include "klee/Internal/Module/KInstruction.h"
#include "klee/Internal/Module/KModule.h"
#include "klee/Internal/Support/FloatEvaluation.h"
#include "klee/Internal/System/Time.h"
#include "klee/Internal/System/MemoryUsage.h"

#if LLVM_VERSION_CODE >= LLVM_VERSION(3, 3)
#include "llvm/IR/Function.h"
#include "llvm/IR/Attributes.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/IR/TypeBuilder.h"
#else
#include "llvm/Attributes.h"
#include "llvm/BasicBlock.h"
#include "llvm/Constants.h"
#include "llvm/Function.h"
#include "llvm/Instructions.h"
#include "llvm/IntrinsicInst.h"
#include "llvm/LLVMContext.h"
#include "llvm/Module.h"
#if LLVM_VERSION_CODE <= LLVM_VERSION(3, 1)
#include "llvm/Target/TargetData.h"
#else
#include "llvm/DataLayout.h"
#include "llvm/TypeBuilder.h"
#endif
#endif
#include "llvm/ADT/SmallPtrSet.h"
#include "llvm/ADT/StringExtras.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/ErrorHandling.h"
#include "llvm/Support/Process.h"
#include "llvm/Support/raw_ostream.h"

#if LLVM_VERSION_CODE < LLVM_VERSION(3, 5)
#include "llvm/Support/CallSite.h"
#else
#include "llvm/IR/CallSite.h"
#endif

#include <cassert>
#include <algorithm>
#include <iomanip>
#include <iosfwd>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

#include <sys/mman.h>

#include <errno.h>
#include <cxxabi.h>

using namespace llvm;
using namespace klee;


#ifdef SUPPORT_METASMT

#include <metaSMT/frontend/Array.hpp>
#include <metaSMT/backend/Z3_Backend.hpp>
#include <metaSMT/backend/Boolector.hpp>
#include <metaSMT/backend/MiniSAT.hpp>
#include <metaSMT/DirectSolver_Context.hpp>
#include <metaSMT/support/run_algorithm.hpp>
#include <metaSMT/API/Stack.hpp>
#include <metaSMT/API/Group.hpp>

#define Expr VCExpr
#define Type VCType
#define STP STP_Backend
#include <metaSMT/backend/STP.hpp>
#undef Expr
#undef Type
#undef STP

using namespace metaSMT;
using namespace metaSMT::solver;

#endif /* SUPPORT_METASMT */

namespace klee{

extern cl::opt<bool> SimplifySymIndices;
extern cl::opt<unsigned> MaxSymArraySize;
extern cl::opt<double> MaxStaticForkPct;
extern cl::opt<double> MaxStaticSolvePct;
extern cl::opt<double> MaxStaticCPForkPct;
extern cl::opt<double> MaxStaticCPSolvePct;
extern cl::opt<unsigned> MaxForks;
extern cl::opt<unsigned> MaxMemoryInhibit;
extern cl::opt<unsigned> MaxDepth;
extern cl::opt<bool> OnlyReplaySeeds;
extern RNG theRNG;

}

MpExecutor::MpExecutor(const InterpreterOptions &opts,
                   InterpreterHandler *ih)
	:
	Executor(opts,ih){
}

MpExecutor::~MpExecutor(){

	}

static bool isDebugIntrinsic(const Function *f, KModule *KM) {
	 return false;
}

static inline const llvm::fltSemantics * fpWidthToSemantics(unsigned width) {
	 switch(width) {
	 case Expr::Int32:
	   return &llvm::APFloat::IEEEsingle;
	 case Expr::Int64:
	   return &llvm::APFloat::IEEEdouble;
     case Expr::Fl80:
	   return &llvm::APFloat::x87DoubleExtended;
	 default:
	   return 0;
    }
}

void MpExecutor::executeInstruction(ExecutionState &state, KInstruction *ki){
	 Instruction *i = ki->inst;

	 //llvm::errs()<<"******executeInstruction*******\n";
	 // llvm::errs()<<"Instruction:  "<<i->getOpcode()<<"\n";

	  switch (i->getOpcode()) {
	    // Control flow

	  case Instruction::Br: {

	//	llvm::errs()<<"*******Br*******\n";

		  BranchInst *bi = cast<BranchInst>(i);
		//llvm::errs()<<"   bi.parent:    "<<*(bi->getParent())<<"\n";
		//llvm::errs()<<"   bi.parentadr:    "<<bi->getParent()<<"\n";
		forblock.insert(bi->getParent());
		//llvm::errs()<<"   bi.parent.time:    "<<forblock.count(bi->getParent())<<"\n";
		//llvm::BasicBlock *tem = bi->getSuccessor(0);
		//llvm::errs()<<"   bi.dr:    "<<tem<<"\n";

	    if (bi->isUnconditional()) {
	    	llvm::BasicBlock *temp = bi->getSuccessor(0);
			//llvm::errs()<<"   bi.block:    "<<*temp<<"\n";
			//llvm::errs()<<"   bi.count:    "<<forblock.count(temp)<<"\n";
	    	//if (forblock.count(temp) != 0 && forblock.count(temp) <= 5)
			if (forflag.size() <= 2 && forblock.count(temp) != 0)
	    	{
				if (forflag.empty() || forflag.back() == temp)forflag.push_back(temp);
				if ( !nowcondition.empty() ) nowcondition.pop_back();
				state.constraints.constraints = nowcondition;
	    		transferToBasicBlock(temp, bi->getParent(), state);
	    		elseblock.pop_back();
	    	}
	    	else if (!elseblock.empty() && visblock.count(temp) != 1)
	    	{
	    		if (forflag.size() >2 ) forflag.clear();
	    		if ( elseblock.back() == temp)
	    		{
	    			if ( !nowcondition.empty() ) nowcondition.pop_back();
	    			state.constraints.constraints = nowcondition;
	    			transferToBasicBlock(temp, bi->getParent(), state);
	    		}
	    		else {
	    			nowcondition.back() = Expr::createIsZero(nowcondition.back());
	    			state.constraints.constraints = nowcondition;
	    			transferToBasicBlock(elseblock.back(), bi->getParent(), state);
	    		}
	    		visblock.insert(temp);
				elseblock.pop_back();
	    	}
	    	else
	    	{
				if ( !nowcondition.empty() ) nowcondition.pop_back();
				state.constraints.constraints = nowcondition;
	    		transferToBasicBlock(temp, bi->getParent(), state);
	    	}

		//	for (int i = 0 ;i < (int)nowcondition.size() ;i++)
			//	llvm::errs()<<"   nowcons "<<i<<"    :  "<<nowcondition[i]<<"\n";

	    } else {
	      // FIXME: Find a way that we don't have this hidden dependency.
	      assert(bi->getCondition() == bi->getOperand(0) &&
	             "Wrong operand index!");
	      ref<Expr> cond = eval(ki, 0, state).value;

	      //llvm::errs()<<"   cond:  "<<cond<<"\n";

	      nowcondition.push_back(cond);
	      Executor::StatePair branches = fork(state, cond, false);

	      // NOTE: There is a hidden dependency here, markBranchVisited
	      // requires that we still be in the context of the branch
	      // instruction (it reuses its statistic id). Should be cleaned
	      // up with convenient instruction specific data.

	      if (statsTracker && state.stack.back().kf->trackCoverage)
	      {
	        statsTracker->markBranchVisited(branches.first, branches.second);
	      }
	      if (branches.first)
	        transferToBasicBlock(bi->getSuccessor(0), bi->getParent(), *branches.first);
	      else if (branches.second)
	      {
	    	  nowcondition.back() = Expr::createIsZero(nowcondition.back());
	          transferToBasicBlock(bi->getSuccessor(1), bi->getParent(), *branches.second);
	      }
	      if (branches.first && branches.second)
	      {
	    	  elseblock.push_back(bi->getSuccessor(1));
	    	  //transferToBasicBlock(bi->getSuccessor(1), bi->getParent(), *branches.second);
	      }

	      //BasicBlock *b0 = bi->getSuccessor(0);
	      //BasicBlock *b1 = bi->getSuccessor(1);
	      //llvm::errs()<<"   b0:  "<<*b0<<"   bi.1:  "<<*b1<<"\n";

	    }
	    break;
	  }

	    // Arithmetic / logical

	  case Instruction::Add: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;

	    unsigned lid = eval(ki, 0, state).id;
	    unsigned rid = eval(ki, 1, state).id;

	    llvm::errs()<<"  lid:          "<<lid<<"\n";
	    llvm::errs()<<"  rid:          "<<rid<<"\n";
	    llvm::errs()<<"   globalstate:          "<<globalstate.size()<<"\n";
	    if (globalstate.find(lid) != globalstate.end() && globalstate.find(rid) != globalstate.end())
	    {
	    	const ObjectState *lstate = globalstate.find(lid)->second;
	    	const ObjectState *rstate = globalstate.find(rid)->second;

	   // llvm::errs()<<"Add               lstate  size:          "<<lstate->constraintStore.size()<<"\n";
	   // llvm::errs()<<"Add               rstate  size:          "<<rstate->constraintStore.size()<<"\n";


	        cons.clear();
	        ans.clear();
	        for (int i = 0 ; i< (int)lstate->constraintStore.size(); i++)
	        	for (int j = 0 ; j< (int)rstate->constraintStore.size(); j++)
	        	{
	        			int p =  (int)rstate->constraintStore.size();
	        			//int q =  (int)lstate->constraintStore.size();<<"  "<<i<<"  "<<p<<"  "<<j<<"  "
	            		llvm::errs()<<"*******"<<i*p+j<<"*******\n";
	            	  //  llvm::errs()<<"   lstate  countadr:          "<< lstate->yn.count(lstate->adr[i])<<"\n";
	            	    //llvm::errs()<<"   rstate  countadr:          "<< rstate->yn.count(lstate->adr[j])<<"\n";

	        			ref<Expr> lvalue = lstate->read(lstate->adr[i],32);
	        			ref<Expr> rvalue = rstate->read(rstate->adr[j],32);

	        		    llvm::errs()<<"  lvalue:          "<<lvalue<<"\n";
	        			for (int x = 0 ;x < (int)lstate->constraintStore[i].constraints.size() ;x++)
	        				llvm::errs()<<"   lstatecons "<<x<<"    :  "<<lstate->constraintStore[i].constraints[x]<<"\n";
	        		    llvm::errs()<<"  rvalue:          "<<rvalue<<"\n";
	        			for (int x = 0 ;x < (int)rstate->constraintStore[j].constraints.size() ;x++)
	        				llvm::errs()<<"   rstatecons "<<x<<"    :  "<<rstate->constraintStore[j].constraints[x]<<"\n";

	            		if ( lstate->yn.count(lstate->adr[i]) >= 1 || rstate->yn.count(rstate->adr[j]) >= 1)
	            		{
	                		llvm::errs()<<"   error\n";
	                		continue;
	            		}

	        			ans.push_back( AddExpr::create(lvalue, rvalue));
	    	    		cons.push_back(lstate->constraintStore[i]);
	    	    		/*
	            		llvm::errs()<<"\n****************\n";
	                    if (!rstate->constraintStore[j].constraints.empty())
	                 	   for (int k = 0 ; k < (int) rstate->constraintStore[j].constraints.size();k++)
	                 	   llvm::errs()<<"  rightcons    "<<k<<"   :  "<<rstate->constraintStore[j].constraints[k]<<"\n";
	                    else llvm::errs()<<"  TRUE\n";
	            		llvm::errs()<<"****************\n\n";
						*/
	    	    		bool result = true;
	    	    		Solver::Validity res;
	        	    	for (int k = 0; k < (int)rstate->constraintStore[j].constraints.size(); k ++)
	        	    	{
	        	    		ref <Expr> temp = rstate->constraintStore[j].constraints[k];
	        	    		cons.back().addConstraint(temp);
	        	    		result = solver->solver->evaluate(Query(cons.back(),temp),res);
	                		//llvm::errs()<<"   constr:       "<<cons.back().constraints.back()<<"      temp:      "<<temp<<"   res :  "<<res<<"\n";
	        	    		if (res == -1) break;
	        	    	}
	        	    	if (res == -1)
	        	    	{
	        	    		cons.pop_back();
	        	    		ans.pop_back();
	        	    	}
	        	    	else //if (false)
	        	    	{
	        	    		llvm::errs()<<"  ans:      "<<ans.back()<<"\n";
	        	    		//if (!cons.back().constraints.empty())
	        	    		//	for (int k = 0 ; k < (int) cons.back().constraints.size();k++)
	        	    		//		llvm::errs()<<"  cons    "<<k<<"   :  "<<cons.back().constraints[k]<<"\n";
	        	    		//else llvm::errs()<<"  TRUE\n";
	        	    	}
	        }
	    }
	    else if ( globalstate.find(lid) == globalstate.end()  || globalstate.find(rid) == globalstate.end() )
	    {
	    	ref <Expr> tem = right;
	    	if  ( globalstate.find(lid) == globalstate.end())
	    	{
	    		unsigned temp =rid;
	    		rid = lid;
	    		lid = temp;
	    		tem = left;
	    	}

	    	const ObjectState *lstate = globalstate.find(lid)->second;
	    	cons.clear();
	    	ans.clear();
	    	for (int i = 0 ; i< (int)lstate->constraintStore.size(); i++)
	    	{
	    		ref<Expr> lvalue = lstate->read(lstate->adr[i],32);
	            llvm::errs()<<"   lvalue:  "<<lvalue<<"\n";
	    	    if ( lstate->yn.count(lstate->adr[i]) >= 1)
	            {
	    	    	llvm::errs()<<"   error\n";
	                continue;
	            }
	    	    ans.push_back( AddExpr::create(lvalue, tem));
	    	    cons.push_back(lstate->constraintStore[i]);
	    	    llvm::errs()<<"  ans:      "<<ans.back()<<"\n";
	    	    if (!cons.back().constraints.empty())
	    	    	for (int k = 0 ; k < (int) cons.back().constraints.size();k++)
	    	    		llvm::errs()<<"  cons    "<<k<<"   :  "<<cons.back().constraints[k]<<"\n";
	    	    else llvm::errs()<<"  TRUE\n";
	    	    }
	    }

	    bindLocal(ki, state, AddExpr::create(left, right), 0);
	    break;
	  }

	  case Instruction::Sub: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    bindLocal(ki, state, SubExpr::create(left, right), 0);
	    break;
	  }

	  case Instruction::Mul: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    bindLocal(ki, state, MulExpr::create(left, right), 0);
	    break;
	  }

	  case Instruction::UDiv: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = UDivExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	  case Instruction::SDiv: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = SDivExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	  case Instruction::URem: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = URemExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	  case Instruction::SRem: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = SRemExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	  case Instruction::And: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = AndExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	  case Instruction::Or: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = OrExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	  case Instruction::Xor: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = XorExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	  case Instruction::Shl: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = ShlExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	  case Instruction::LShr: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = LShrExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	  case Instruction::AShr: {
	    ref<Expr> left = eval(ki, 0, state).value;
	    ref<Expr> right = eval(ki, 1, state).value;
	    ref<Expr> result = AShrExpr::create(left, right);
	    bindLocal(ki, state, result, 0);
	    break;
	  }

	    // Compare

	  case Instruction::ICmp: {
	    CmpInst *ci = cast<CmpInst>(i);
	    ICmpInst *ii = cast<ICmpInst>(ci);

	    //llvm::errs()<<"   comp:  "<<ii->getPredicate()<<"\n";
	    switch(ii->getPredicate()) {
	    case ICmpInst::ICMP_EQ: {		//		==
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = EqExpr::create(left, right);
	      bindLocal(ki, state, result, 0);
	      break;
	    }

	    case ICmpInst::ICMP_NE: {		//		&&
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = NeExpr::create(left, right);
	      bindLocal(ki, state, result, 0);
	      break;
	    }

	    case ICmpInst::ICMP_UGT: {
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = UgtExpr::create(left, right);
	      bindLocal(ki, state,result, 0);
	      break;
	    }

	    case ICmpInst::ICMP_UGE: {
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = UgeExpr::create(left, right);
	      bindLocal(ki, state, result, 0);
	      break;
	    }

	    case ICmpInst::ICMP_ULT: {
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = UltExpr::create(left, right);
	      bindLocal(ki, state, result, 0);
	      break;
	    }

	    case ICmpInst::ICMP_ULE: {
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = UleExpr::create(left, right);
	      bindLocal(ki, state, result, 0);
	      break;
	    }

	    case ICmpInst::ICMP_SGT: {		//		>
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = SgtExpr::create(left, right);
	      bindLocal(ki, state, result, 0);
	      break;
	    }

	    case ICmpInst::ICMP_SGE: {		//		>=
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = SgeExpr::create(left, right);
	      bindLocal(ki, state, result, 0);
	      break;
	    }

	    case ICmpInst::ICMP_SLT: {		//		<
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = SltExpr::create(left, right);
	      bindLocal(ki, state, result, 0);
	      break;
	    }

	    case ICmpInst::ICMP_SLE: {		//		<=
	      ref<Expr> left = eval(ki, 0, state).value;
	      ref<Expr> right = eval(ki, 1, state).value;
	      ref<Expr> result = SleExpr::create(left, right);
	      bindLocal(ki, state, result, 0);
	      break;
	    }

	    default:
	      terminateStateOnExecError(state, "invalid ICmp predicate");
	    }
	    break;
	  }

	    // Memory instructions...
	  case Instruction::Alloca: {
	    AllocaInst *ai = cast<AllocaInst>(i);
	    unsigned elementSize =
	      kmodule->targetData->getTypeStoreSize(ai->getAllocatedType());
	    ref<Expr> size = Expr::createPointer(elementSize);
	    if (ai->isArrayAllocation()) {
	      ref<Expr> count = eval(ki, 0, state).value;
	      count = Expr::createZExtToPointerWidth(count);
	      size = MulExpr::create(size, count);
	    }
	    bool isLocal = i->getOpcode()==Instruction::Alloca;

	    executeAlloc(state, size, isLocal, ki, 0);
	    break;
	  }

	  case Instruction::Load: {
	    ref<Expr> base = eval(ki, 0, state).value;

	  llvm::errs()<<"*******load*******\n";

	    executeMemoryOperation(state, false, base, 0, ki);
	    break;
	  }
	  case Instruction::Store: {
	    ref<Expr> base = eval(ki, 1, state).value;
	    ref<Expr> value = eval(ki, 0, state).value;

	   llvm::errs()<<"*******Store*******\n"<<"   value:  "<<value<<"\n";
		//if (!state.constraints.empty())llvm::errs()<<"    state:  "<< state.constraints.back()<<"\n";

	    executeMemoryOperation(state, true, base, value, 0);
	    break;
	  }

	  default:
		 Executor::executeInstruction(state,ki);
	    break;
	  }
}

	  void MpExecutor::executeMemoryOperation(ExecutionState &state,
	                                        bool isWrite,
	                                        ref<Expr> address,
	                                        ref<Expr> value /* undef if read */,
	                                        KInstruction *target /* undef if write */) {

	   //   llvm::errs()<<"*******executeMemoryOperation*******\n";

	  	Expr::Width type = (isWrite ? value->getWidth() :
	                       getWidthForLLVMType(target->inst->getType()));
	    unsigned bytes = Expr::getMinBytesForWidth(type);

	    if (SimplifySymIndices) {
	      if (!isa<klee::ConstantExpr>(address))
	        address = state.constraints.simplifyExpr(address);
	      if (isWrite && !isa<klee::ConstantExpr>(value))
	        value = state.constraints.simplifyExpr(value);
	    }

	    // fast path: single in-bounds resolution
	    ObjectPair op;
	    bool success;
	    solver->setTimeout(coreSolverTimeout);


	    if (!state.addressSpace.resolveOne(state, solver, address, op, success)) {
	      address = toConstant(state, address, "resolveOne failure");
	      success = state.addressSpace.resolveOne(cast<klee::ConstantExpr>(address), op);
	    }
	    solver->setTimeout(0);

	    if (success) {
	      const MemoryObject *mo = op.first;

	      if (MaxSymArraySize && mo->size>=MaxSymArraySize) {
	        address = toConstant(state, address, "max-sym-array-size");
	      }

	      ref<Expr> offset = mo->getOffsetExpr(address);

	      bool inBounds;
	      solver->setTimeout(coreSolverTimeout);
	      bool success = solver->mustBeTrue(state,
	                                        mo->getBoundsCheckOffset(offset, bytes),
	                                        inBounds);
	      solver->setTimeout(0);
	      if (!success) {
	        state.pc = state.prevPC;
	        terminateStateEarly(state, "Query timed out (bounds check).");
	        return;
	      }

	      if (inBounds) {
	        const ObjectState *os = op.second;
	        if (isWrite) {
	          if (os->readOnly) {
	            terminateStateOnError(state,
	                                  "memory error: object read only",
	                                  "readonly.err");
	          } else {
	            ObjectState *wos = state.addressSpace.getWriteable(mo, os);

	            wos->write(offset, value,state.constraints);
	            if (!nowcondition.empty())
	            {
	            	    Solver::Validity res;
	    	    		bool result = true;
	            		for ( int i = 0; i < (int )wos->constraintStore.size() ; i ++)
	            		{
	            			if ( wos->lastad == wos->adr[i]) continue;
	            			//if (!wos->constraintStore[i].constraints.empty())llvm::errs()<<"   adr:     "<<wos->adr[i]<<"   nowcondition:  "<<nowcondition.back()<<"   wos.cons:  "<<wos->constraintStore[i].constraints.back()<<"\n";
	        	    	    result = solver->solver->evaluate(Query(wos->constraintStore[i],(Expr::createIsZero(nowcondition.back()))),res);
	            			wos->constraintStore[i].addConstraint(Expr::createIsZero(nowcondition.back()));
	            			//llvm::errs()<<"---------res----------     "<<res<<"----------------\n";
	            			if (res == -1) wos->yn.insert(wos->adr[i]);
	            		}
	            }

	          }
	        } else {
	          ref<Expr> result = os->read(offset, type);

	          if (interpreterOpts.MakeConcreteSymbolic)
	          {
	            result = replaceReadWithSymbolic(state, result);
	          }
	          if (globalstate.count(os->object->id) == 1) globalstate.erase(os->object->id);
	           globalstate.insert(std::make_pair(os->object->id,os)) ;
	           //llvm::errs()<<"   os.id:  "<<os->object->id<<"   target.dest:  "<<target->dest<<"\n";
	           //llvm::errs()<<"   state.value:  "<< state.stack.size()<<"\n";
	          bindLocal(target, state, result,os->object->id);
	        }
	        return;
	      }
	    }

	    // we are on an error path (no resolution, multiple resolution, one
	    // resolution with out of bounds)

	    ResolutionList rl;
	    solver->setTimeout(coreSolverTimeout);


	    bool incomplete = state.addressSpace.resolve(state, solver, address, rl,
	                                                 0, coreSolverTimeout);
	    solver->setTimeout(0);

	    // XXX there is some query wasteage here. who cares?
	    ExecutionState *unbound = &state;

	    for (ResolutionList::iterator i = rl.begin(), ie = rl.end(); i != ie; ++i) {
	      const MemoryObject *mo = i->first;
	      const ObjectState *os = i->second;
	      ref<Expr> inBounds = mo->getBoundsCheckPointer(address, bytes);

	      StatePair branches = fork(*unbound, inBounds, true);
	      ExecutionState *bound = branches.first;

	      // bound can be 0 on failure or overlapped
	      if (bound) {
	        if (isWrite) {
	          if (os->readOnly) {
	            terminateStateOnError(*bound,
	                                  "memory error: object read only",
	                                  "readonly.err");
	          } else {
	            ObjectState *wos = bound->addressSpace.getWriteable(mo, os);


	            wos->write(mo->getOffsetExpr(address), value,state.constraints);
	          }
	        } else {
	          ref<Expr> result = os->read(mo->getOffsetExpr(address), type);

	          //globalstate.insert(std::make_pair(os->object->id,os)) ;
	          bindLocal(target, *bound, result,os->object->id);
	        }
	      }

	      unbound = branches.second;
	      if (!unbound)
	        break;
	    }

	    // XXX should we distinguish out of bounds and overlapped cases?
	    if (unbound) {
	      if (incomplete) {
	        terminateStateEarly(*unbound, "Query timed out (resolve).");
	      } else {
	        terminateStateOnError(*unbound,
	                              "memory error: out of bound pointer",
	                              "ptr.err",
	                              getAddressInfo(*unbound, address));
	      }
	    }
	  }


	  Executor::StatePair
	  MpExecutor::fork(ExecutionState &current, ref<Expr> condition, bool isInternal) {
	    Solver::Validity res;
	    std::map< ExecutionState*, std::vector<SeedInfo> >::iterator it =
	      seedMap.find(&current);
	    bool isSeeding = it != seedMap.end();

	    if (!isSeeding && !isa<klee::ConstantExpr>(condition) &&
	        (MaxStaticForkPct!=1. || MaxStaticSolvePct != 1. ||
	         MaxStaticCPForkPct!=1. || MaxStaticCPSolvePct != 1.) &&
	        statsTracker->elapsed() > 60.) {
	      StatisticManager &sm = *theStatisticManager;
	      CallPathNode *cpn = current.stack.back().callPathNode;
	      if ((MaxStaticForkPct<1. &&
	           sm.getIndexedValue(stats::forks, sm.getIndex()) >
	           stats::forks*MaxStaticForkPct) ||
	          (MaxStaticCPForkPct<1. &&
	           cpn && (cpn->statistics.getValue(stats::forks) >
	                   stats::forks*MaxStaticCPForkPct)) ||
	          (MaxStaticSolvePct<1 &&
	           sm.getIndexedValue(stats::solverTime, sm.getIndex()) >
	           stats::solverTime*MaxStaticSolvePct) ||
	          (MaxStaticCPForkPct<1. &&
	           cpn && (cpn->statistics.getValue(stats::solverTime) >
	                   stats::solverTime*MaxStaticCPSolvePct))) {
	        ref<klee::ConstantExpr> value;
	        bool success = solver->getValue(current, condition, value);
	        assert(success && "FIXME: Unhandled solver failure");
	        (void) success;
	        addConstraint(current, EqExpr::create(value, condition));
	        condition = value;
	      }
	    }

	    double timeout = coreSolverTimeout;
	    if (isSeeding)
	      timeout *= it->second.size();
	    solver->setTimeout(timeout);
	    bool success = solver->evaluate(current, condition, res);
	    solver->setTimeout(0);
	    if (!success) {
	      current.pc = current.prevPC;
	      terminateStateEarly(current, "Query timed out (fork).");
	      return StatePair(0, 0);
	    }

	    if (!isSeeding) {
	      if (replayPath && !isInternal) {
	        assert(replayPosition<replayPath->size() &&
	               "ran out of branches in replay path mode");
	        bool branch = (*replayPath)[replayPosition++];

	        if (res==Solver::True) {
	          assert(branch && "hit invalid branch in replay path mode");
	        } else if (res==Solver::False) {
	          assert(!branch && "hit invalid branch in replay path mode");
	        } else {
	          // add constraints
	          if(branch) {
	            res = Solver::True;
	            addConstraint(current, condition);
	          } else  {
	            res = Solver::False;
	            addConstraint(current, Expr::createIsZero(condition));
	          }
	        }
	      } else if (res==Solver::Unknown) {
	        assert(!replayOut && "in replay mode, only one branch can be true.");

	        if ((MaxMemoryInhibit && atMemoryLimit) ||
	            current.forkDisabled ||
	            inhibitForking ||
	            (MaxForks!=~0u && stats::forks >= MaxForks)) {

	  	if (MaxMemoryInhibit && atMemoryLimit)
	  	  klee_warning_once(0, "skipping fork (memory cap exceeded)");
	  	else if (current.forkDisabled)
	  	  klee_warning_once(0, "skipping fork (fork disabled on current path)");
	  	else if (inhibitForking)
	  	  klee_warning_once(0, "skipping fork (fork disabled globally)");
	  	else
	  	  klee_warning_once(0, "skipping fork (max-forks reached)");

	          TimerStatIncrementer timer(stats::forkTime);
	          if (theRNG.getBool()) {
	            addConstraint(current, condition);
	            res = Solver::True;
	          } else {
	            addConstraint(current, Expr::createIsZero(condition));
	            res = Solver::False;
	          }
	        }
	      }
	    }

	    // Fix branch in only-replay-seed mode, if we don't have both true
	    // and false seeds.
	    if (isSeeding &&
	        (current.forkDisabled || OnlyReplaySeeds) &&
	        res == Solver::Unknown) {
	      bool trueSeed=false, falseSeed=false;
	      // Is seed extension still ok here?
	      for (std::vector<SeedInfo>::iterator siit = it->second.begin(),
	             siie = it->second.end(); siit != siie; ++siit) {
	        ref<klee::ConstantExpr> res;
	        bool success =
	          solver->getValue(current, siit->assignment.evaluate(condition), res);
	        assert(success && "FIXME: Unhandled solver failure");
	        (void) success;
	        if (res->isTrue()) {
	          trueSeed = true;
	        } else {
	          falseSeed = true;
	        }
	        if (trueSeed && falseSeed)
	          break;
	      }
	      if (!(trueSeed && falseSeed)) {
	        assert(trueSeed || falseSeed);

	        res = trueSeed ? Solver::True : Solver::False;
	        addConstraint(current, trueSeed ? condition : Expr::createIsZero(condition));
	      }
	    }

	  	if (res == Solver::True){
	  	   // ExecutionState *trueState = &current;
	  	   // addConstraint(*trueState, condition);

	  	// llvm::errs()<<"----------true----------\n";
	      if (!isInternal) {
	        if (pathWriter) {
	          current.pathOS << "1";
	        }
	      }

	      return StatePair(&current, 0);
	    } else if (res==Solver::False) {

	  //	llvm::errs()<<"----------false----------\n";
	      if (!isInternal) {
	        if (pathWriter) {
	          current.pathOS << "0";
	        }
	      }

	      return StatePair(0, &current);
	    } else {


	      TimerStatIncrementer timer(stats::forkTime);
	      ExecutionState *trueState = &current, *falseState;

	      ++stats::forks;

	     falseState = trueState->branch();

	      current.ptreeNode->data = 0;
	      std::pair<PTree::Node*, PTree::Node*> res =
	        processTree->split(current.ptreeNode, falseState, trueState);
	      falseState->ptreeNode = res.first;
	    trueState->ptreeNode = res.second;

	      if (!isInternal) {
	        if (pathWriter) {
	          falseState->pathOS = pathWriter->open(current.pathOS);
	          trueState->pathOS << "1";
	          falseState->pathOS << "0";
	        }
	        if (symPathWriter) {
	          falseState->symPathOS = symPathWriter->open(current.symPathOS);
	          trueState->symPathOS << "1";
	          falseState->symPathOS << "0";
	        }
	      }

	      addConstraint(*trueState, condition);
	      addConstraint(*falseState, Expr::createIsZero(condition));

	      // Kinda gross, do we even really still want this option?
	      if (MaxDepth && MaxDepth<=trueState->depth) {
	        terminateStateEarly(*trueState, "max-depth exceeded.");
	        terminateStateEarly(*falseState, "max-depth exceeded.");
	        return StatePair(0, 0);
	      }

	      return StatePair(trueState, falseState);
	    }
	  }

	  void MpExecutor::bindLocal(KInstruction *target, ExecutionState &state,
	                           ref<Expr> value , unsigned id) {
	    getDestCell(state, target).value = value;
	    getDestCell(state, target).id = id;
	  }


Interpreter *Interpreter::createmp(const InterpreterOptions &opts,
                                 InterpreterHandler *ih) {
  return new MpExecutor(opts, ih);
}

